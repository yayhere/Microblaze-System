#include "PmodKYPD.h"
#include "sleep.h"
#include "xil_printf.h"
#include "xparameters.h"

PmodKYPD myDevice;
#define DEFAULT_KEYTABLE "0FED789C456B123A"

// wrapper to get a single key press using the Pmod Driver
char get_key_press() {
    u16 keystate;
    XStatus status, last_status = KYPD_NO_KEY;
    u8 key, last_key = 'x';

    // flush any previous keys
    KYPD_getKeyStates(&myDevice);

    while (1) {
        // capture state of each key
        keystate = KYPD_getKeyStates(&myDevice);

        // determine which single key is pressed
        status = KYPD_getKeyPressed(&myDevice, keystate, &key);

        // return the key only if it is a NEW single press
        if (status == KYPD_SINGLE_KEY && key != 0) {
             // wait for release, prevents spamming
             while(KYPD_getKeyStates(&myDevice) != 0);
             return (char)key;
        }
        usleep(1000); // small delay to prevent CPU hogging
    }
}

int read_number() {
    char c;
    while(1) {
        c = inbyte();

        // ignore "Enter" keys (newlines) so we don't print errors twice
        if (c == '\r' || c == '\n') {
            continue;
        }

        // echo the character the user typed
        xil_printf("%c", c);

        // validate input (1, 2, or 3)
        if(c >= '1' && c <= '3') {
            xil_printf("\r\n");
            return c - '0';
        }
        else {
            // invalid input detected
            xil_printf("\r\nInvalid input! Please enter 1, 2, or 3.\r\n");
            xil_printf("Make the first move, Player 1 (PC): ");
        }
    }
}

int main()
{
    // Initialize Pmod Keypad
    KYPD_begin(&myDevice, XPAR_PMODKYPD_0_AXI_LITE_GPIO_BASEADDR);
    KYPD_loadKeyTable(&myDevice, (u8*) DEFAULT_KEYTABLE);

    int serial_move;
    int keypad_move;
    char keypad_char;
    const char *dic[] = {"Invalid", "Rock", "Paper", "Scissors"};

    xil_printf("\r\n--- Rock-Paper-Scissors Serial-Keypad Game ---\r\n");
    xil_printf("Rules: 1 = Rock, 2 = Paper, 3 = Scissors\r\n");

    while (1)
    {
        // Player 1 (PC)
        xil_printf("\r\nMake the first move, Player 1 (PC): ");
        serial_move = read_number();
        xil_printf("\r\n"); // Clean new line after input

        // Player 2 (FPGA) Turn
        xil_printf("Your turn, Player 2 (FPGA): ");

        // loop specifically for FPGA until valid input is received
        while (1) {
            keypad_char = get_key_press(); // wait for a key press

            // check if valid move (1, 2, or 3)
            if (keypad_char >= '1' && keypad_char <= '3') {
                 keypad_move = keypad_char - '0';
                 xil_printf("%c\r\n", keypad_char); // echo the valid move
                 break; // break out of the FPGA loop to finish the game
            }
            else {
                 // invalid input: print error and loop back to top of FPGA turn
                 xil_printf("\r\nInvalid Keypad Move! Try again.\r\n");
                 xil_printf("Your turn, Player 2 (FPGA): ");
            }
        }

        // game logic
        if (serial_move == keypad_move) {
             xil_printf("Result: Draw! %s == %s\r\n", dic[serial_move], dic[keypad_move]);
        }
        else if ((serial_move == 1 && keypad_move == 3) ||
                 (serial_move == 2 && keypad_move == 1) ||
                 (serial_move == 3 && keypad_move == 2)) {
            xil_printf("Result: PC won! %s > %s\r\n", dic[serial_move], dic[keypad_move]);
        }
        else {
            xil_printf("Result: FPGA won! %s < %s\r\n", dic[serial_move], dic[keypad_move]);
        }

        // delay before next round
        sleep(2);
    }
    return 0;
}
